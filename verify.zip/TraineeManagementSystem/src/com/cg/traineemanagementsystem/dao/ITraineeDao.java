package com.cg.traineemanagementsystem.dao;

import java.util.ArrayList;

import com.cg.traineemanagementsystem.bean.LoginBean;
import com.cg.traineemanagementsystem.bean.Trainee;

public interface ITraineeDao {
	public boolean validate(LoginBean lb);
	public void insertData(Trainee tr);
	public ArrayList<Trainee> removeDataview(Integer tId);
	public void removeData(Integer tId);
	public ArrayList<Trainee> modifydata(Integer tId);
}
