package com.cg.traineemanagementsystem.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="trainee_info")
@NamedQueries({@NamedQuery(name="deleteview",query="select t from Trainee t where t.tId=:id"),
	@NamedQuery(name="modifydataview",query="select t from Trainee t where t.tId=:id1")
})

public class Trainee {
	@Id
	/*@GeneratedValue(strategy=GenerationType.SEQUENCE)*/
	@Column(name="trainee_id")
	private Integer tId;
	@Column(name="trainee_name")
	private String tName;
	@Column(name="trainee_location")
	private String tLocation;
	@Column(name="trainee_domain")
	private String tDomain;

	public Integer gettId() {
		return tId;
	}

	public void settId(Integer tId) {
		this.tId = tId;
	}

	public String gettName() {
		return tName;
	}

	public void settName(String tName) {
		this.tName = tName;
	}

	public String gettLocation() {
		return tLocation;
	}

	public void settLocation(String tLocation) {
		this.tLocation = tLocation;
	}

	public String gettDomain() {
		return tDomain;
	}

	public void settDomain(String tDomain) {
		this.tDomain = tDomain;
	}

}
