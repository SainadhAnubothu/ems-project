package com.cg.traineemanagementsystem.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.traineemanagementsystem.bean.LoginBean;
import com.cg.traineemanagementsystem.bean.Trainee;
import com.cg.traineemanagementsystem.service.ITraineeService;
@Controller
public class TraineeController {
	
	@Autowired
	ITraineeService ts;
	
	@RequestMapping("index")
	public ModelAndView getHomePage(Model m){
		ModelAndView mv=new ModelAndView();
		LoginBean lb=new LoginBean();
		mv.setViewName("LoginPage");
		mv.addObject("lb",lb);
		return mv;	
	}
	
	@RequestMapping(value="/check",method=RequestMethod.POST)
	public ModelAndView validate(@ModelAttribute("lb") LoginBean lb,Model m){
		ModelAndView mv=new ModelAndView();
		mv.setViewName("operations");
		Boolean res=ts.validate(lb);
		return mv;
		
	}
	@RequestMapping(value="/addtrainee")
	public ModelAndView add(Model m){
		Trainee tr=new Trainee();
		ModelAndView mv=new ModelAndView();
		mv.addObject("tr",tr);
		ArrayList<String> list=new ArrayList<>();
		list.add("JEE");
		list.add("JEE ABRIDGED");
		list.add("DOT NET");
		list.add("ORAPPS");
		list.add("TESTING");
		mv.addObject("domainlist",list);
		ArrayList<String> list1=new ArrayList<>();
		list1.add("Chennai");
		list1.add("Banglore");
		list1.add("Pune");
		list1.add("Mumbai");
		mv.addObject("locationlist",list1);
		mv.setViewName("addtrainee");
		return mv;	
	}
	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public ModelAndView insertData(@ModelAttribute("tr") Trainee tr,Model m){
		ModelAndView mv=new ModelAndView();
		mv.setViewName("operations");
		ts.insertData(tr);
		return mv;	
	}
	@RequestMapping(value="/deletetrainee")
	public ModelAndView deleteData(Model m){
		ModelAndView mv=new ModelAndView();
		Trainee t=new Trainee();
		mv.addObject("tr",t);
		mv.setViewName("delete");
		return mv;
	}
	@RequestMapping(value="/remove")
	public ModelAndView removeData(@ModelAttribute("tr") Trainee t,Model m){
		ModelAndView mv=new ModelAndView();
		Trainee tr=new Trainee();
		mv.addObject("tr",tr);
		mv.setViewName("delete");
		ArrayList<Trainee> list=new ArrayList<Trainee>();
		list=ts.removeDataview(t.gettId());
		mv.addObject("deleteviewlist",list);
		return mv;
	}
	@RequestMapping(value="/removedata")
	public ModelAndView remove(@ModelAttribute("tr") Trainee t,Model m){
		ModelAndView mv=new ModelAndView();
		mv.setViewName("operations");
		ts.removeData(t.gettId());
		return mv;
	}
	@RequestMapping(value="/modifytrainee")
	public ModelAndView modify(Model m){
		ModelAndView mv=new ModelAndView();
		Trainee tr=new Trainee();
		mv.addObject("tr", tr);
		mv.setViewName("modify");
		return mv;
	}
	
	@RequestMapping(value="/modifyid",method=RequestMethod.POST)
	public ModelAndView modifyid(@ModelAttribute("tr") Trainee t,Model m){
		ModelAndView mv=new ModelAndView();
		Trainee tr=new Trainee();
		mv.addObject("tr", tr);
		ArrayList<Trainee> list=new ArrayList<>();
		list=ts.modifydata(t.gettId());
		mv.addObject("modifydatalist",list);
		mv.setViewName("modify");
		return mv;
	}
}
