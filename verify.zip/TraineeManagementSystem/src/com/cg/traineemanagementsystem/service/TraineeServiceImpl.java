package com.cg.traineemanagementsystem.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.traineemanagementsystem.bean.LoginBean;
import com.cg.traineemanagementsystem.bean.Trainee;
import com.cg.traineemanagementsystem.dao.ITraineeDao;

@Service
public class TraineeServiceImpl implements ITraineeService{

	@Autowired
	ITraineeDao td;
	
	@Override
	public boolean validate(LoginBean lb) {
		return td.validate(lb);
	}

	@Override
	public void insertData(Trainee tr) {
		// TODO Auto-generated method stub
		 td.insertData(tr);
	}

	@Override
	public ArrayList<Trainee> removeDataview(Integer tId) {
		// TODO Auto-generated method stub
		ArrayList<Trainee> list=new ArrayList<>();
		list=td.removeDataview(tId);
		return list;
	}

	@Override
	public void removeData(Integer tId) {
		// TODO Auto-generated method stub
		td.removeData(tId);
		
	}

	@Override
	public ArrayList<Trainee> modifydata(Integer tId) {
		// TODO Auto-generated method stub
		ArrayList<Trainee> list=new ArrayList<>();
		list=td.modifydata(tId);
		return null;
	}


}
