package com.cg.employeemaintenancesystem.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.employeemaintenancesystem.beans.EmployeeBean;
import com.cg.employeemaintenancesystem.beans.EmployeeDetails;
import com.cg.employeemaintenancesystem.beans.UserBean;
import com.cg.employeemaintenancesystem.dao.EmployeeDaoImpl;
import com.cg.employeemaintenancesystem.dao.IEmployeeDao;
import com.cg.employeemaintenancesystem.exception.EmployeeMaintenanceException;

public class EmployeeServiceImpl implements IEmployeeService {
	IEmployeeDao di = new EmployeeDaoImpl();

	@Override
	public EmployeeDetails idSearch(String id) throws SQLException,
			EmployeeMaintenanceException {
		EmployeeDetails ed = new EmployeeDetails();
		ed = di.idSearch(id);
		return ed;

	}

	@Override
	public ArrayList<EmployeeDetails> firstNameSearch(String firstName)
			throws SQLException, EmployeeMaintenanceException {
		ArrayList<EmployeeDetails> list = new ArrayList<>();
		list = di.firstNameSearch(firstName);
		return list;
	}

	@Override
	public ArrayList<EmployeeDetails> lastNameSearch(String lastName)
			throws SQLException, EmployeeMaintenanceException {
		ArrayList<EmployeeDetails> list = new ArrayList<>();
		list = di.lastNameSearch(lastName);
		return list;
	}

	@Override
	public ArrayList<EmployeeDetails> deptSearch(String department)
			throws SQLException, EmployeeMaintenanceException {
		ArrayList<EmployeeDetails> list = new ArrayList<>();
		list = di.deptSearch(department);
		return list;
	}

	@Override
	public ArrayList<EmployeeDetails> gradeSearch(String grade)
			throws SQLException, EmployeeMaintenanceException {
		ArrayList<EmployeeDetails> list = new ArrayList<>();
		list = di.gradeSearch(grade);
		return list;
	}

	@Override
	public ArrayList<EmployeeDetails> maritalStatusSearch(String maritalStatus)
			throws SQLException, EmployeeMaintenanceException {
		ArrayList<EmployeeDetails> list = new ArrayList<>();
		list = di.maritalStatusSearch(maritalStatus);
		return list;

	}

	@Override
	public int insertLeaveDetails(EmployeeDetails ed) throws SQLException,
			EmployeeMaintenanceException {
		return di.insertLeaveDetails(ed);
	}

	@Override
	public UserBean getUserType(UserBean user) throws SQLException,
			EmployeeMaintenanceException {

		return di.getUsertype(user);
	}

	@Override
	public boolean addEmployee(EmployeeBean emp) throws SQLException,
			EmployeeMaintenanceException {
		boolean result = di.addEmployee(emp);

		return result;

	}

	@Override
	public boolean checkEmpid(String emyid) throws SQLException,EmployeeMaintenanceException {
		boolean result=di.checkEmpid(emyid);
		return result;
	}

	@Override
	public boolean checkSalary(String grade, int salary) throws SQLException,EmployeeMaintenanceException {
		return di.checkSalary(grade,salary);
	}

	@Override
	public boolean modifyEmployee(EmployeeBean emp) throws SQLException,
			EmployeeMaintenanceException {
		return di.modifyEmployee(emp);
	}

	@Override
	public ArrayList<EmployeeDetails> display() throws SQLException, EmployeeMaintenanceException {
		ArrayList<EmployeeDetails> list=new ArrayList<EmployeeDetails>();
		list= di.display();
		return list;
	}

	@Override
	public String leaveGrantDecision(String userId) throws SQLException, EmployeeMaintenanceException{
		return di.leaveGrantDecision(userId);
		
	}

	@Override
	public boolean approval(UserBean user) throws SQLException, EmployeeMaintenanceException{
		// TODO Auto-generated method stub
		return di.approval(user);
	}

	@Override
	public boolean rejection(UserBean user) throws SQLException, EmployeeMaintenanceException{
		// TODO Auto-generated method stub
		return di.rejection(user);
	}

}
