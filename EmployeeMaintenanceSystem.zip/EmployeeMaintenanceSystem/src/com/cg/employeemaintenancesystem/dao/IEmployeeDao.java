package com.cg.employeemaintenancesystem.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.employeemaintenancesystem.beans.EmployeeBean;
import com.cg.employeemaintenancesystem.beans.UserBean;
import com.cg.employeemaintenancesystem.exception.EmployeeMaintenanceException;

public interface IEmployeeDao {
	public EmployeeBean idSearch(String id) throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeBean> firstNameSearch(String firstName) throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeBean> lastNameSearch(String lastName) throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeBean> deptSearch(String department) throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeBean> gradeSearch(String grade)throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeBean> maritalStatusSearch(String maritalStatus)throws SQLException, EmployeeMaintenanceException;
	public int insertLeaveDetails(EmployeeBean ed) throws SQLException, EmployeeMaintenanceException;
	public UserBean getUsertype(UserBean user) throws SQLException, EmployeeMaintenanceException;
	public boolean addEmployee(EmployeeBean emp) throws SQLException, EmployeeMaintenanceException;
	public boolean checkEmpid(String emyid) throws SQLException, EmployeeMaintenanceException;
	public boolean checkSalary(String grade, int salary) throws SQLException, EmployeeMaintenanceException;
	public boolean modifyEmployee(EmployeeBean emp) throws SQLException, EmployeeMaintenanceException;
	public ArrayList<EmployeeBean> display() throws SQLException, EmployeeMaintenanceException;
	public String leaveGrantDecision(String userId) throws SQLException, EmployeeMaintenanceException;
	public boolean approval(UserBean user) throws SQLException, EmployeeMaintenanceException;
	public boolean rejection(UserBean user) throws SQLException, EmployeeMaintenanceException;	
}
