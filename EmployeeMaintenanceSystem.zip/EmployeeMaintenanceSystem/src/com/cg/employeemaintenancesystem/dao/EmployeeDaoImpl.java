package com.cg.employeemaintenancesystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.employeemaintenancesystem.beans.EmployeeBean;
import com.cg.employeemaintenancesystem.beans.UserBean;
import com.cg.employeemaintenancesystem.exception.EmployeeMaintenanceException;
import com.cg.employeemaintenancesystem.util.DBConnection;

public class EmployeeDaoImpl implements IEmployeeDao {
	public Connection conn;
	DBConnection dbconn = new DBConnection();
	PreparedStatement pst;

	@Override
	public EmployeeBean idSearch(String id) throws SQLException,
			EmployeeMaintenanceException {
		conn = dbconn.getConnection();
		pst = conn
				.prepareStatement(IQueryMapper.IDSEARCH);
		pst.setString(1, id);
		ResultSet rs = pst.executeQuery();
		EmployeeBean ed = new EmployeeBean();
		while (rs.next()) {
			ed.setEmpId(rs.getString(1));
			ed.setFirstName(rs.getString(2));
			ed.setLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setEmpGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
		}
		return ed;
	}

	@Override
	public ArrayList<EmployeeBean> firstNameSearch(String firstName)
			throws SQLException, EmployeeMaintenanceException {
		conn = dbconn.getConnection();
		pst = conn
				.prepareStatement(IQueryMapper.FIRSTNAMESEARCH);
		pst.setString(1, firstName);
		ResultSet rs = pst.executeQuery();
		ArrayList<EmployeeBean> list = new ArrayList<>();
		while (rs.next()) {
			EmployeeBean ed = new EmployeeBean();
			ed.setEmpId(rs.getString(1));
			ed.setFirstName(rs.getString(2));
			ed.setLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setEmpGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;
	}

	@Override
	public ArrayList<EmployeeBean> lastNameSearch(String lastName)
			throws SQLException, EmployeeMaintenanceException {
		conn = dbconn.getConnection();
		pst = conn
				.prepareStatement(IQueryMapper.LASTNAMESEARCH);
		pst.setString(1, lastName);
		ResultSet rs = pst.executeQuery();
		ArrayList<EmployeeBean> list = new ArrayList<>();
		while (rs.next()) {
			EmployeeBean ed = new EmployeeBean();
			ed.setEmpId(rs.getString(1));
			ed.setFirstName(rs.getString(2));
			ed.setLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setEmpGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;

	}

	@Override
	public ArrayList<EmployeeBean> deptSearch(String department)
			throws SQLException, EmployeeMaintenanceException {
		conn = dbconn.getConnection();
		pst = conn
				.prepareStatement(IQueryMapper.DEPTSEARCH);
		pst.setString(1, department);
		ResultSet rs = pst.executeQuery();
		ArrayList<EmployeeBean> list = new ArrayList<>();
		while (rs.next()) {
			EmployeeBean ed = new EmployeeBean();
			ed.setEmpId(rs.getString(1));
			ed.setFirstName(rs.getString(2));
			ed.setLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setEmpGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;

	}

	@Override
	public ArrayList<EmployeeBean> gradeSearch(String grade)
			throws SQLException, EmployeeMaintenanceException {
		conn = dbconn.getConnection();
		pst = conn
				.prepareStatement(IQueryMapper.GRADESEARCH);
		pst.setString(1, grade);
		ResultSet rs = pst.executeQuery();
		ArrayList<EmployeeBean> list = new ArrayList<>();
		while (rs.next()) {
			EmployeeBean ed = new EmployeeBean();
			ed.setEmpId(rs.getString(1));
			ed.setFirstName(rs.getString(2));
			ed.setLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setEmpGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;
	}

	@Override
	public ArrayList<EmployeeBean> maritalStatusSearch(String maritalStatus)
			throws SQLException, EmployeeMaintenanceException {
		conn = dbconn.getConnection();
		pst = conn
				.prepareStatement(IQueryMapper.MARITALSEARCH);
		pst.setString(1, maritalStatus);
		ResultSet rs = pst.executeQuery();
		ArrayList<EmployeeBean> list = new ArrayList<>();
		while (rs.next()) {
			EmployeeBean ed = new EmployeeBean();
			ed.setEmpId(rs.getString(1));
			ed.setFirstName(rs.getString(2));
			ed.setLastName(rs.getString(3));
			ed.setDepartment(rs.getString(4));
			ed.setEmpGrade(rs.getString(5));
			ed.setEmpDesignation(rs.getString(6));
			list.add(ed);
		}
		return list;
	}

	@Override
	public int insertLeaveDetails(EmployeeBean ed) throws SQLException,
			EmployeeMaintenanceException {
		conn = dbconn.getConnection();
		System.out.println(conn);
		pst = conn
				.prepareStatement(IQueryMapper.LEAVEDETAILS);
		pst.setString(1, "1006");
		pst.setInt(2, 12);
		pst.setInt(3, ed.getDiff());
		pst.setDate(4, Date.valueOf(ed.getFromDate()));
		pst.setDate(5, Date.valueOf(ed.getToDate()));
		pst.setString(6, "applied");
		int val = pst.executeUpdate();
		return val;
	}

	@Override
	public UserBean getUsertype(UserBean user) throws SQLException,
			EmployeeMaintenanceException {
		conn = dbconn.getConnection();		
		pst=conn.prepareStatement(IQueryMapper.USERTYPE);
		pst.setString(1,user.getUserName());
		pst.setString(2,user.getUserpassword());
		ResultSet rs = pst.executeQuery();
		if (rs.next()) {
			user.setUserId(rs.getString(2));
			user.setUserType(rs.getString(1));
		}
		return user;

	}

	@Override
	public boolean addEmployee(EmployeeBean emp) throws SQLException,
			EmployeeMaintenanceException {
		boolean result = false;
		try {
			conn = dbconn.getConnection();
			pst = conn
					.prepareStatement(IQueryMapper.ADDEMP);
			pst.setString(1, emp.getEmpId());
			pst.setString(2, emp.getFirstName());
			pst.setString(3, emp.getLastName());
			pst.setDate(13, Date.valueOf(emp.getDob()));
			pst.setDate(14, Date.valueOf(emp.getDoj()));
			pst.setString(4, emp.getEmpDesignation());
			pst.setInt(5, emp.getEmpSalary());
			pst.setString(6, emp.getGender());
			pst.setString(7, emp.getMaritalStatus());
			pst.setString(8, emp.getAddress());
			pst.setString(9, emp.getContactNo());
			pst.setString(10, emp.getManagerId());
			pst.setInt(11, emp.getDeptId());
			pst.setString(12, emp.getEmpGrade());
			int val = pst.executeUpdate();
			if(val==1)
				result=true;
			else
				result=false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public boolean checkEmpid(String emyid) throws SQLException,
			EmployeeMaintenanceException {
		boolean result = false;
		try {
			conn = dbconn.getConnection();
			pst = conn
					.prepareStatement(IQueryMapper.CHECKEMPID);
			pst.setString(1, emyid);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				result = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public boolean checkSalary(String grade, int salary) throws SQLException,
			EmployeeMaintenanceException {
		boolean result = false;
		try {
			conn = dbconn.getConnection();
			PreparedStatement pst = conn
					.prepareStatement(IQueryMapper.CHECKSALARY);
			pst.setString(1, grade);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				int min = rs.getInt(1);
				int max = rs.getInt(2);
				if (salary >= min && salary <= max) {
					result = true;
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;
	}

	@Override
	public boolean modifyEmployee(EmployeeBean emp) throws SQLException,
			EmployeeMaintenanceException {
		boolean result=false;
		try {
			conn = dbconn.getConnection();
			PreparedStatement pst=conn.prepareStatement(IQueryMapper.MODIFYEMP);
			pst.setString(1,emp.getFirstName() );
			pst.setString(2, emp.getLastName());
			pst.setInt(3,emp.getDeptId() );
			pst.setString(4,emp.getEmpGrade() );
			pst.setString(5,emp.getEmpDesignation() );
			pst.setInt(6,emp.getEmpSalary() );
			pst.setString(7,emp.getMaritalStatus() );
			pst.setString(8,emp.getAddress() );
			pst.setString(9,emp.getContactNo() );
			pst.setString(10,emp.getEmpId() );
				int val=pst.executeUpdate();
				if(val==1)
					result=true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return result;
	}

	@Override
	public ArrayList<EmployeeBean> display()
			throws SQLException, EmployeeMaintenanceException {
		ArrayList<EmployeeBean> empList = new ArrayList<EmployeeBean>();
		conn = dbconn.getConnection();
		pst=conn.prepareStatement(IQueryMapper.DISPLAYALL);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			EmployeeBean e = new EmployeeBean();
			e.setEmpId(rs.getString(1));
			e.setFirstName(rs.getString(2));
			e.setLastName(rs.getString(3));
			e.setDepartment(rs.getString(4));
			e.setEmpGrade(rs.getString(5));
			e.setEmpDesignation(rs.getString(6));
			empList.add(e);
		}
		return empList;		
	}
	@Override
	public String leaveGrantDecision(String userId) throws SQLException,EmployeeMaintenanceException {
		//Scanner sc = new Scanner(System.in);
		String msg="Employee eligible for leave.Do you approve or reject??";
		conn = dbconn.getConnection();
		double days =0;
		pst = conn.prepareStatement(IQueryMapper.LEAVEDECISION);
		pst.setString(1,userId);
		ResultSet rs = pst.executeQuery();
		while(rs.next())
		{	
			String leave_id = rs.getString(1);
			String emp_id = rs.getString(2);
			String leave_balance = rs.getString(3);
			String noofdays_applied = rs.getString(4);
			Date date_from = rs.getDate(5);
			Date date_to = rs.getDate(6);
			Date applied_date = rs.getDate(7);
			String status = rs.getString(8);
			System.out.println("  "+leave_id+"  "+emp_id+"  "+leave_balance+"  "+noofdays_applied+"  "+date_from+"  "+date_to+"  "+applied_date+"  "+status);
			pst=conn.prepareStatement(IQueryMapper.DAYS);
			pst.setInt(1, rs.getInt(1));
			ResultSet res = pst.executeQuery();
			if(res.next())
			 days = res.getDouble(1);
			if(days>=3){
				pst=conn.prepareStatement(IQueryMapper.APPROVELEAVE);
				pst.setInt(1, rs.getInt(4));
				pst.setInt(2,rs.getInt(1));
				pst.executeUpdate();
			}
			else
			 msg="Employee eligible for leave.Do you approve or reject??";
			
		}
		return msg;
	}

	@Override
	public boolean approval(UserBean user) throws SQLException, EmployeeMaintenanceException {
		conn = dbconn.getConnection();
		boolean result=false;
		
		pst = conn.prepareStatement(IQueryMapper.LEAVEDECISION);
		pst.setString(1,user.getUserId());
		ResultSet rs = pst.executeQuery();
		while(rs.next()){
			
		PreparedStatement pst1=conn.prepareStatement(IQueryMapper.APPROVELEAVE);
		pst1.setInt(1,rs.getInt(4));
		pst1.setInt(2, rs.getInt(1));
		int val=pst1.executeUpdate();
		System.out.println(val);
		if(val==1)
			result=true;
		else
			result=false;
	}
		return result; 
		}
	

	@Override
	public boolean rejection(UserBean user) throws SQLException, EmployeeMaintenanceException {
		conn = dbconn.getConnection();
		boolean result=false;
		pst = conn.prepareStatement(IQueryMapper.LEAVEDECISION);
		pst.setString(1,user.getUserId());
		ResultSet rs = pst.executeQuery();
		while(rs.next()){
		pst=conn.prepareStatement(IQueryMapper.REJECTLEAVE);
		pst.setInt(1,rs.getInt(1));
		int val=pst.executeUpdate();
		if(val==1)
			result=true;
		else
			result=false;
	}
		return result;
}
}