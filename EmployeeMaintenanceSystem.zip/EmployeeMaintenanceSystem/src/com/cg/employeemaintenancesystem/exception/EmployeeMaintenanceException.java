package com.cg.employeemaintenancesystem.exception;

public class EmployeeMaintenanceException extends Exception {

	public EmployeeMaintenanceException() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeMaintenanceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
