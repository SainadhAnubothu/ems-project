package com.cg.employeemaintenancesystem.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.employeemaintenancesystem.entity.Employee;
import com.cg.employeemaintenancesystem.entity.LeaveHistory;
import com.cg.employeemaintenancesystem.entity.UserMaster;

@Repository
@Transactional
public class EMSDaoImpl implements IEMSDao{

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public ArrayList<UserMaster> checkLoginCredentials(String userName, String userPassword) {
		Query query=entityManager.createNamedQuery("checkLogin");
		query.setParameter("userName", userName);
		query.setParameter("userPassword", userPassword);
		ArrayList<UserMaster> userDetails=(ArrayList<UserMaster>) query.getResultList();
		return userDetails;
	}

	@Override
	public String adminAddEmployee(Employee employee) {
		System.out.println("in dao:"+employee);
		entityManager.persist(employee);
		entityManager.flush();
		return employee.getEmployeeId();
	}

	@Override
	public String adminModifyEmployee(Employee employee) {
		entityManager.merge(employee);
		entityManager.flush();
		return employee.getEmployeeId();
	}

	@Override
	public ArrayList<Employee> adminDisplayAllEmployees() {
		ArrayList<Employee> displayAllEmployees=(ArrayList<Employee>) entityManager.createNamedQuery("displayAll").getResultList();
		return displayAllEmployees;
	}

	@Override
	public ArrayList<LeaveHistory> adminLeaveDecision(String userId,
			String decision) {
		return null;
	}

	@Override
	public ArrayList<Employee> userIdSearchEmployee(String employeeId) {
		System.out.println(employeeId);
		ArrayList<Employee> idSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("idSearch").setParameter("employeeId", employeeId).getResultList();
		return idSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userFirstNameSearchEmployee(String firstName) {
		// TODO Auto-generated method stub
		ArrayList<Employee> firstNameSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("firstNameSearch").setParameter("firstName", firstName).getResultList();
		return firstNameSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userLastNameSearchEmployee(String lastName) {
		// TODO Auto-generated method stub
		ArrayList<Employee> lastNameSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("lastNameSearch").setParameter("lastName", lastName).getResultList();
		return lastNameSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userGradeSearchEmployee(String gradeCode) {
		// TODO Auto-generated method stub
		ArrayList<Employee> gradeSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("gradeSearch").setParameter("grade", gradeCode).getResultList();
		return gradeSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userDepartmentSearchEmployee(
			String departmentName) {
		// TODO Auto-generated method stub
		ArrayList<Employee> departmentSearchEmployee=(ArrayList<Employee>) entityManager.createQuery("select employee.employeeId,employee.firstName,employee.lastName,department.departmentName,employee.grade,employee.designation from Employee employee join Department department on department.departmentId=employee.departmentId where department.departmentName=:departmentName").setParameter("departmentName", departmentName).getResultList();
		return departmentSearchEmployee;
	}

	@Override
	public ArrayList<Employee> userMaritalStatusSearchEmployee(
			String maritalStatus) {
		// TODO Auto-generated method stub
		ArrayList<Employee> maritalStatusSearchEmployee=(ArrayList<Employee>) entityManager.createNamedQuery("maritalStatusSearch").setParameter("maritalStatus", maritalStatus).getResultList();
		return maritalStatusSearchEmployee;
	}

	@Override
	public ArrayList<LeaveHistory> userApplyLeave(LeaveHistory leaveHistory) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<LeaveHistory> adminApproveLeave(Integer leaveId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<LeaveHistory> adminRejectLeave(Integer leaveId) {
		// TODO Auto-generated method stub
		return null;
	}

}
